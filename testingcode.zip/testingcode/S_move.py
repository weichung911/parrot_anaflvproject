import olympe
import subprocess
import time
from olympe.messages.ardrone3.Piloting import TakeOff, Landing, PCMD
from olympe.messages.gimbal import set_target
from pynput.keyboard import Listener, Key, KeyCode
from collections import defaultdict
from enum import Enum

#DRONE_IP = "192.168.42.1"
DRONE_IP = "10.202.0.1"
#drone = olympe.Drone(DRONE_IP)
if __name__ == "__main__":
    with olympe.Drone(DRONE_IP) as drone:
        drone.connection()
        drone(TakeOff()).wait().success()
        time.sleep(1)
        for i in range(0,10):
            drone(PCMD(1,
                               0,#control.roll(), #-100,0,100 # 左右平移
                               0,#control.pitch(),#-100,0,100# 前進後退
                               10,#control.yaw(),#-100,0,100# 左右旋轉
                               0,#control.throttle(),#-100,0,100# 上升下降
                               timestampAndSeqNum=0,
                         ))
            drone(set_target(gimbal_id = 0,
              control_mode = "position",
              yaw_frame_of_reference = "relative",
                      yaw = 0,#control.camera_yaw(),#-100,0,100# 鏡頭左右旋
                      pitch_frame_of_reference = "relative",
                      pitch = 0,#control.camera_pitch(),#-100,0,100# 鏡頭俯仰
                      roll_frame_of_reference = "relative",
                      roll = 0 #control.camera_roll()#-100,0,100# 鏡頭左右移
                     )).wait

            time.sleep(1)
