
import numpy as np
import cv2

def boundingRect(h,w,cnt):
    top = h
    down = 0
    left = w
    right = 0
    for i in range(len(cnt)):
        if(top > cnt[i][0]):
            top = cnt[i][0]
        if(down < cnt[i][0]):
            down =cnt[i][0]
        if(left > cnt[i][1]):
            left = cnt[i][1]
        if(right < cnt[i][1]):
            right =cnt[i][1]
    h = down - top;
    w = right - left;
    y = top
    x = left

    return x,y,w,h



image = cv2.imread('can')
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
# cv2.imshow("Original",image)
# cv2.waitKey(0)
height,width = image.shape[:2]
red = np.array([55,16,24])
color_range = np.array([50,50,50])
img2 = image
c = 0
#
for x in range(0,width,3):
    for y in range(0,height,3):
        temp = image[y,x,:]
        if (all(red + color_range > image[y,x,:]) & all(image[y,x,:]> red - color_range)):
            img2[y,x,:] = [255,0,0]
            if (c == 0):
                cnt = [[y,x]]
                c = 1
            else:
                cnt.append([y,x])

# print(cnt[0])
x, y, w, h = boundingRect(height,width,cnt)
print(x)
print(y)
print(w)
print(h)
cv2.rectangle(img2, (x, y), (x + w, y + h), (0, 255, 0), 2)


img2 = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
#R、G、B分量的提取
# (B,G,R) = cv2.split(image)#提取R、G、B分量
cv2.imshow("Red",img2)
# cv2.imshow("Green",G)
# cv2.imshow("Blue",B)
cv2.waitKey(0)
