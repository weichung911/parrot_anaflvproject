# -*- coding: UTF-8 -*-

import olympe
import subprocess
import time
from olympe.messages.ardrone3.Piloting import TakeOff, Landing, PCMD
from olympe.messages.gimbal import set_target
from pynput.keyboard import Listener, Key, KeyCode
from collections import defaultdict
from enum import Enum

#DRONE_IP = "192.168.42.1"
DRONE_IP = "10.202.0.1"

if __name__ == "__main__":
    with olympe.Drone(DRONE_IP) as drone:
        drone.connection()
while not control.quit():
            if control.takeoff():
                drone(TakeOff())
            elif control.landing():
                drone(Landing())
            if control.has_piloting_cmd():
                drone(PCMD(1,
                           control.roll(), #-100,0,100 # 左右平移
                           control.pitch(),#-100,0,100# 前進後退
                           control.yaw(),#-100,0,100# 左右旋轉
                           control.throttle(),#-100,0,100# 上升下降
                           timestampAndSeqNum=0,
                     ))
                drone(set_target(gimbal_id = 0,
		      control_mode = "position",
		      yaw_frame_of_reference = "relative",
                      yaw = control.camera_yaw(),#-100,0,100# 鏡頭左右旋
                      pitch_frame_of_reference = "relative",
                      pitch = control.camera_pitch(),#-100,0,100# 鏡頭俯仰
      	              roll_frame_of_reference = "relative",
                      roll = control.camera_roll()#-100,0,100# 鏡頭左右移
                     )).wait
            else:
                drone(PCMD(0, 0, 0, 0, 0, timestampAndSeqNum=0))
                drone(set_target(gimbal_id = 0,
		      control_mode = "position",
		      yaw_frame_of_reference = "relative",
                      yaw = 0.0,
                      pitch_frame_of_reference = "relative",
                      pitch = 0.0,
      	              roll_frame_of_reference = "relative",
                      roll = 0.0
                     )).wait
            time.sleep(0.05)
