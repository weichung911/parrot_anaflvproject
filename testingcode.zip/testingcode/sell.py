import os
import subprocess
# import multiprocessing as mp
# print('123')
# start_dire = r"/home/advailab-pc4/pythonProject/step1.py"
# os.system("python step1.py")
# s1 = mp.Process(target=os.system,args=("python step1.py"))
# s2 = mp.Process(target=print,args=('1223'))
# s1.start()
# s2.start()
#
# print('1223')
# os.system('sphinx /opt/parrot-sphinx/usr/share/sphinx/drones/anafi4k.drone::stolen_interface=::simple_front_cam=true')
subprocess.Popen('sphinx /opt/parrot-sphinx/usr/share/sphinx/drones/anafi4k.drone::stolen_interface=::simple_front_cam=true')
