import numpy as np
from cv2 import cv2
from matplotlib import pyplot as plt
from PIL import Image


def getcolor(img):
    lower_red = np.array([160, 60, 60])
    upper_red = np.array([180, 255, 255])

    lower_red2 = np.array([70, 87, 0])
    upper_red2 = np.array([179, 255, 255])  # thers is two ranges of red


    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    cv2.imshow('123',hsv)
    mask_r = cv2.inRange(hsv, lower_red, upper_red)

    mask_r2 = cv2.inRange(hsv, lower_red2, upper_red2)

    mask = mask_r + mask_r2

    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    mask = cv2.dilate(mask, kernel,iterations = 4)

    mask = cv2.erode(mask, kernel, iterations = 3)

    res = cv2.bitwise_and(img, img, mask=mask)

    gray_img = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
    # 降噪
    ret, thresh = cv2.threshold(mask, 150, 255, 0)
    # 尋找輪廓
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)

    cnt = contours[0]
    print(cnt)
    # 外接正矩形
    x, y, w, h = cv2.boundingRect(cnt)
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
    img2 = img[:,:,::-1]
    return img2

# img = cv2.imread(r'can',1)

# cv2.imshow('one',img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

img=Image.open('can')
print(type(img))
img = np.array(img)
print(type(img))
img = getcolor(img)
cv2.imshow('one',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
# img.show()
getcolor(img)


# im2.show()
# # 顯示圖片
# cv.imshow("gray_img", img)
#
# # 等待輸入
# cv.waitKey(0)
# cv.destroyAllWindows()
# getcolor(img)

