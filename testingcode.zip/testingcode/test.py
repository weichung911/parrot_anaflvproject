
import time
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GObject, Gdk, GdkPixbuf
import matplotlib.pyplot as plt # plt 用于显示图片
import matplotlib.image as mpimg # mpimg 用于读取图片
import numpy as np
from PIL import Image
import os
import cv2


def pixbuf2image(pix):
    """Convert gdkpixbuf to PIL image"""
    data = pix.get_pixels()
    w = pix.props.width
    h = pix.props.height
    stride = pix.props.rowstride
    mode = "RGB"
    if pix.props.has_alpha == True:
        mode = "RGBA"
    im = Image.frombytes(mode, (w, h), data, "raw", mode, stride)
    return im
def boundingRect(h,w,cnt):
    top = h
    down = 0
    left = w
    right = 0
    for i in range(len(cnt)):
        if(top > cnt[i][0]):
            top = cnt[i][0]
        if(down < cnt[i][0]):
            down =cnt[i][0]
        if(left > cnt[i][1]):
            left = cnt[i][1]
        if(right < cnt[i][1]):
            right =cnt[i][1]
    h = down - top;
    w = right - left;
    y = top
    x = left

    return x,y,w,h

def getcolor(image):
    height,width = image.shape[:2]
    red = np.array([55,16,24])
    color_range = np.array([50,50,50])
    img2 = image
    c = 0
    m = 0
    #
    for x in range(0,width,3):
        for y in range(0,height,3):
            temp = image[y,x,:]
            if (all(red + color_range > image[y,x,:]) & all(image[y,x,:]> red - color_range)):
                img2[y,x,:] = [255,0,0]
                if (c == 0):
                    cnt = [[y,x]]
                    c = 1
                    m = 1
                else:
                    cnt.append([y,x])

    # print(cnt[0])
    if (m == 1):
        x, y, w, h = boundingRect(height,width,cnt)
    # print(x)
    # print(y)
    # print(w)
    # print(h)
        cv2.rectangle(img2, (x, y), (x + w, y + h), (0, 255, 0), 2)


    # img2 = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return img2

def screen():
    # screenshots for all windows
    window = Gdk.get_default_root_window()
    screen = window.get_screen()
    typ = window.get_type_hint()
    for i, wi in enumerate(screen.get_window_stack()):
        pb = Gdk.pixbuf_get_from_window(wi, *wi.get_geometry())
        w = pb.props.width
        h = pb.props.height

        if (w,h) == (840,525):
            plt.clf()

            im = pixbuf2image(pb)
            im = np.array(im)
            imS = cv2.resize(im, (420, 262))
            im = getcolor(imS)

            #1
            plt.imshow(im)
            plt.draw()
            print('1')
            plt.pause(0.00000001)
            #2
            # BGR = cv2.cvtColor(im, cv2.COLOR_RGB2BGR)
            # # imS = cv2.resize(BGR, (420, 262))
            # cv2.imshow('frame', BGR)
            # print('1')
            # time.sleep(0.1)
            # if cv2.waitKey(1) & 0xFF == ord('q'):
            #     break

            # print(im)

            # os.makedirs("new_project")
            # os.chdir('new_project')
            # pb.savev('\\new_project\\'+"{}.png".format(i), "png", (), ())


i = 0
m0 = 0

while(i == 0):
    screen()

