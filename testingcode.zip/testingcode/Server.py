#!/usr/bin/env python3
"""Server for multithreaded (asynchronous) chat application."""
from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
import olympe
import subprocess
import time
from olympe.messages.ardrone3.Piloting import TakeOff, Landing, PCMD
from olympe.messages.gimbal import set_target
from pynput.keyboard import Listener, Key, KeyCode
from collections import defaultdict
from enum import Enum

def accept_incoming_connections():
    """Sets up handling for incoming clients."""
    while True:
        client, client_address = SERVER.accept()
        print("%s:%s has connected." % client_address)
        client.send(bytes("Greetings from the cave! Now type your name and press enter!", "utf8"))
        addresses[client] = client_address
        Thread(target=handle_client, args=(client,)).start()


def handle_client(client):  # Takes client socket as argument.
    """Handles a single client connection."""

    name = client.recv(BUFSIZ).decode("utf8")
    welcome = 'Welcome %s! If you ever want to quit, type {quit} to exit.' % name
    client.send(bytes(welcome, "utf8"))
    msg = "%s has joined the chat!" % name
    broadcast(bytes(msg, "utf8"))
    clients[client] = name

    while True:
        msg = client.recv(BUFSIZ)
        data = msg.decode('utf-8')
        data = eval(data)
        print(data[0])
        if ((data[0] > 0) & (data[1] >0)):
            with olympe.Drone(DRONE_IP) as drone:
                if(data[0] < 400):
                    roll = 10
                elif(data[0] > 428):
                    roll = -10
                else:
                    roll = 0
                if(data[1] < 208):
                    throttle = 10
                elif(data[1] < 228):
                    throttle = -10
                else:
                    throttle = 0

                drone(PCMD(1,
                                   roll,#control.roll(), #-100,0,100 # 左右平移
                                   0,#control.pitch(),#-100,0,100# 前進後退
                                   0,#control.yaw(),#-100,0,100# 左右旋轉
                                   throttle,#control.throttle(),#-100,0,100# 上升下降
                                   timestampAndSeqNum=0,
                             ))
                drone(set_target(gimbal_id = 0,
                  control_mode = "position",
                  yaw_frame_of_reference = "relative",
                          yaw = 0,#control.camera_yaw(),#-100,0,100# 鏡頭左右旋
                          pitch_frame_of_reference = "relative",
                          pitch = 0,#control.camera_pitch(),#-100,0,100# 鏡頭俯仰
                          roll_frame_of_reference = "relative",
                          roll = 0 #control.camera_roll()#-100,0,100# 鏡頭左右移
                         )).wait
                time.sleep(0.05)
        if msg != bytes("{quit}", "utf8"):
            broadcast(msg, name+": ")
        else:
            client.send(bytes("{quit}", "utf8"))
            client.close()
            del clients[client]
            broadcast(bytes("%s has left the chat." % name, "utf8"))
            break


def broadcast(msg, prefix=""):  # prefix is for name identification.
    """Broadcasts a message to all the clients."""

    for sock in clients:
        sock.send(bytes(prefix, "utf8")+msg)


clients = {}
addresses = {}
DRONE_IP = "10.202.0.1"
HOST = '127.0.0.1'
PORT = 33000
BUFSIZ = 1024
ADDR = (HOST, PORT)
drone = olympe.Drone(DRONE_IP)

SERVER = socket(AF_INET, SOCK_STREAM)
SERVER.bind(ADDR)

if __name__ == "__main__":
    SERVER.listen(5)
    print("Waiting for connection...")
    ACCEPT_THREAD = Thread(target=accept_incoming_connections)
    ACCEPT_THREAD.start()
    ACCEPT_THREAD.join()
    SERVER.close()
