import cv2
import numpy as np
from PIL import Image
# img=Image.open('can2.png')
# print(type(img))
# img = np.array(img)
# img = img[:,:,::-1]
img = cv2.imread('can2.png')

# range of red
lower_red = np.array([160, 60, 60])
upper_red = np.array([180, 255, 255])

lower_red2 = np.array([70, 87, 0])
upper_red2 = np.array([179, 255, 255])  # thers is two ranges of red

# range of yellow
# lower_yellow = np.array([10,100,100])
# upper_yellow = np.array([45,255,255])

# range of grenn
# lower_yellow = np.array([36,25,25])
# upper_yellow = np.array([70,255,255])

# change to hsv model
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

mask_r = cv2.inRange(hsv, lower_red, upper_red)

mask_r2 = cv2.inRange(hsv, lower_red2, upper_red2)

mask = mask_r + mask_r2

# cv2.namedWindow('Mask', 0)
# cv2.imshow('Mask', mask)
# cv2.waitKey()

kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
mask = cv2.dilate(mask, kernel,iterations = 10 )

mask = cv2.erode(mask, kernel, iterations = 5)
cv2.namedWindow('Mask_dilate', 0)
cv2.imshow('Mask_dilate', mask)
cv2.waitKey()

# 将mask于原视频帧进行按位与操作，则会把mask中的白色用真实的图像替换：
res = cv2.bitwise_and(img, img, mask=mask)

cv2.namedWindow('res', 0)
cv2.imshow('res', res)
cv2.waitKey()

gray_img = cv2.cvtColor(res, cv2.COLOR_BGR2GRAY)
# 降噪
ret, thresh = cv2.threshold(mask, 150, 255, 0)
# 尋找輪廓
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
cv2.namedWindow('res', 0)
cv2.imshow('res', thresh)
cv2.waitKey()

cnt = contours[0]
print(len(cnt))
# 外接正矩形
x, y, w, h = cv2.boundingRect(cnt)
cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

# 外接最小矩形
# min_rect = cv2.minAreaRect(cnt)
# print(min_rect)
#
# box = cv2.boxPoints(min_rect)
# box = np.int0(box)
# cv2.drawContours(img, [box], 0, (0, 0, 255), 2)

cv2.imshow("draw", img)

cv2.waitKey(0)
cv2.destroyAllWindows()
